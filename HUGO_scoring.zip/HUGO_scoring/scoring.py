## Load the necessary library
import numpy as np
import pandas as pd
import sys
import os

## SMAPE definition
"""
Notice 0.5 factor on denominator is ignored to get the error between 0-100
"""
def smape(A, F, z=1e-10):
    return 100/len(A) * np.sum(np.abs(F - A) / (np.abs(A) + np.abs(F) + z))



"""
Create a helper function to assist reviewer to score for all the participants
"""
def calculate_combined_score(ground_truth_file, forecast_directory):
    ground_truth_df = pd.read_csv(ground_truth_file)
    participant_detailed_forecast = []
    file_list = os.listdir(forecast_directory)
    for file in file_list:
        file_id = str(file).split(".")[0]
        file_df = pd.read_csv(os.path.join(forecast_directory,file))
        file_df["id"] = file_id
        participant_detailed_forecast.append(file_df)
        
    participant_detailed_forecast = \
    pd.concat(participant_detailed_forecast, sort=True)
    
    kpi1_scoring = []
    kpi2_scoring = []
    kpi3_scoring = []
    kpi4_scoring = []
    kpi5_scoring = []
    kpi6_scoring = []
    
    participants_id = participant_detailed_forecast["id"].unique()
    
    # KPI1 scoring
    for participant in participants_id:
        forecast = \
        participant_detailed_forecast[participant_detailed_forecast["id"]==participant].\
        iloc[:,0].values
        actual = ground_truth_df.iloc[:,0].values
        kpi1_scoring.append(100 - smape(actual, forecast))
        
    # KPI2 scoring
    for participant in participants_id:
        forecast = \
        participant_detailed_forecast[participant_detailed_forecast["id"]==participant].\
        iloc[:,1].values
        actual = ground_truth_df.iloc[:,1].values
        kpi2_scoring.append(100 - smape(actual, forecast))
        
    # KPI3 scoring
    for participant in participants_id:
        forecast = \
        participant_detailed_forecast[participant_detailed_forecast["id"]==participant].\
        iloc[:,2].values
        actual = ground_truth_df.iloc[:,2].values
        kpi3_scoring.append(100 - smape(actual, forecast))
        
    # KPI4 scoring
    for participant in participants_id:
        forecast = \
        participant_detailed_forecast[participant_detailed_forecast["id"]==participant].\
        iloc[:,3].values
        actual = ground_truth_df.iloc[:,3].values
        kpi4_scoring.append(100 - smape(actual, forecast))
        
    # KPI5 scoring
    for participant in participants_id:
        forecast = \
        participant_detailed_forecast[participant_detailed_forecast["id"]==participant].\
        iloc[:,4].values
        actual = ground_truth_df.iloc[:,4].values
        kpi5_scoring.append(100 - smape(actual, forecast))
        
        
    # KPI6 scoring
    for participant in participants_id:
        forecast = \
        participant_detailed_forecast[participant_detailed_forecast["id"]==participant].\
        iloc[:,5].values
        actual = ground_truth_df.iloc[:,5].values
        kpi6_scoring.append(100 - smape(actual, forecast))
        
    
        
    ## Normalize KPI scores for each participants (divide each participant's score by max score of that KPI)
    normalized_kpi1_score = np.array(kpi1_scoring)/np.max(np.array(kpi1_scoring))
    normalized_kpi2_score = np.array(kpi2_scoring)/np.max(np.array(kpi2_scoring))
    normalized_kpi3_score = np.array(kpi3_scoring)/np.max(np.array(kpi3_scoring))
    normalized_kpi4_score = np.array(kpi4_scoring)/np.max(np.array(kpi4_scoring))
    normalized_kpi5_score = np.array(kpi5_scoring)/np.max(np.array(kpi5_scoring))
    normalized_kpi6_score = np.array(kpi6_scoring)/np.max(np.array(kpi6_scoring))
    
    
    ## Combine the scores
    normalized_combined_kpi_score = np.column_stack([normalized_kpi1_score,
                                                     normalized_kpi2_score,
                                                     normalized_kpi3_score,
                                                     normalized_kpi4_score,
                                                     normalized_kpi5_score,
                                                     normalized_kpi6_score
                                                     ])
    
    
    ## Summing up
    summed_up_kpi_score_for_participant = np.sum(normalized_combined_kpi_score, axis=1)
    
    score_df = \
    pd.DataFrame(summed_up_kpi_score_for_participant,columns=["normalized_score"])
    
    score_df["participant_id"] = participants_id
    
    return score_df.sort_values(by="normalized_score", ascending=False)

if __name__ == "__main__":
   input_file_name = str(sys.argv[1])
   input_dir_name = str(sys.argv[2])
   score_df = calculate_combined_score(input_file_name, input_dir_name)
   print(score_df)
