To calculate the score one should get the ground truth values in ground_truth_file.csv (name is a parameter in the script, so feel free to change the name as necessary). This file should have 6 columns and n rows where n=number of points to be forecasted. As an example, the current file have 30 days 24 hours data = 24*30=720 data points and 6 columns.

In the directory participants forecast, one should place all the subission csv files. All the submission csv files should be same format as ground truth csv file (order of KPI columns should be same in order to run the auto scoring)

After putting all the submissions in the directory, run the following:
`
python scoring.py <gt_file> <forecast_dir>
`
example could be run as 

`
python scoring.py ground_truth_file.csv participants_forecast
`

This will print the score for each participant in standard output.

